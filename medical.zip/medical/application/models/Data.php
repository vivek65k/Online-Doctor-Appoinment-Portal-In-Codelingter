<?php

/**
* 
*/
class Data extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}
	function appoiment_insert($data){

		$this->db->insert('Appointment',$data);
		echo "<script>alert('Data has been inserted sucessfully')</script> ";
					redirect("http://localhost/medical/index.php/Hello/Redirect");
	}
	function insert_data($dat){
		$this->db->insert('subscribe',$dat);
		redirect("http://localhost/medical/index.php/Hello/Subscribe");
	}
	function data_insert($dta){
		$this->db->insert('Contect',$dta);
			redirect("http://localhost/medical/index.php/Hello/Redirect");
	}
	function fetch_data()
 	{
 		$query =$this->db->get("News");
 		return $query;
 		

 	}
 	function singup_data($singup){
		$this->db->insert('user_regstration',$singup);
			redirect("http://localhost/medical/index.php/Hello/Redirect");
	}
	function cheak_login($email,$password){
		$this->db->where('email',$email);
		$this->db->where('password',$password);
		$ans=$this->db->get('user_regstration');

		$user=$ans->result_array();
		return $user; 

	}
         function unknown_data($unknown){
		$this->db->insert('unknown',$unknown);
			redirect("http://localhost/medical/index.php/Hello/Redirect");
	}


      function showAllEmployee(){
		
		$query = $this->db->get('news');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
   function doctor_data(){
   	$query =$this->db->get("News");
 		return $query;

   }

	
}

?>