<?php

/**
 * 
 */
class Admin_data extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();

	}
	function fetch_data()
 	{
 		$query =$this->db->get("appointment");
 		return $query;
 		

 	}
 	function news_insert($data){

		$this->db->insert('News',$data);
		echo "<script>alert('Data has been inserted sucessfully')</script> ";
					redirect("http://localhost/medical/index.php/Admin/Table");
	}
	function register_insert($dt){

		$this->db->insert('register',$dt);
		echo "<script>alert('Data has been inserted sucessfully')</script> ";
					redirect("http://localhost/medical/index.php/Hello/Redirect");
	}
	function cheak_login($email,$password){
		$this->db->where('email',$email);
		$this->db->where('password',$password);
		$ans=$this->db->get(' register');
		$user=$ans->result_array();
		return $user; 

	}
	function delete($delete_id){
		$this->db->where('id',$delete_id);
		$this->db->delete('appointment');
		return $this->db->affected_rows();
	}
        
        function single_data($id){
        	$this->db->where("id",$id);
        	$query=$this->db->get("appointment");
        	return $query;
        }

        function fetch_dat()
 	{
 		$query =$this->db->get("unknown");
 		return $query;
 	}

 	function doctor_data(){
 		$query =$this->db->get("news");
 		return $query;
 	}
 	function delete_doctor($doctor_id){
		$this->db->where('id',$doctor_id);
		$this->db->delete('news');
		return $this->db->affected_rows();
	}

	function subscribe_data(){
		$query =$this->db->get("subscribe");
 		return $query;

	}
 }

?>