<?php
/**
 * 
 */
class Admin extends CI_Controller
{
	
	function __construct()
	{
	   parent::__construct();
         $this->load->model('Admin_data');
    }
    function index()
	 {
	 	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');

	 	$data["fetch_data"]=$this->Admin_data->fetch_data();
	 	$this->load->view("Admin_view",$data);
	 }

	 function Log(){
	 	$this->load->view('Login_view');
	 }

	 function cheak_login(){
		$email=$this->input->post('email');
		$password=$this->input->post('password');
		$result=$this->Admin_data->cheak_login($email,$password);
		if (count($result)==1) {
	
			session_start();
			$_SESSION['admin']=$result[0];
			header('location:http://localhost/medical/index.php/Admin');

		}
			else{
				echo "<script>alert('failed')</script> ";

		}

	}
	  function Register(){
	  	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');

	 	 if ($_POST) {
			$dt=array(
           'fistname'=>$this->input->post('fistname'),
            'lastname'=>$this->input->post('lastname'),
            'email'=>$this->input->post('email'),
            'password'=>$this->input->post('password'),
              'confpassword'=>$this->input->post('confpassword')

				 );
			$this->Admin_data->register_insert($dt);


		}
		else{
		$this->load->view('Register_view');
	 }
	}
	  function Chart(){
	  	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');

	 	$this->load->view('Chart_view');
	 }
	 function Eroor(){
	 	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');
	 	$this->load->view('Eroor_view');
	 }
	  function Blank(){
	  	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');
	 	$this->load->view('Blank_view');
	 }

  function Subscribe(){
  	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');
		$data["subscribe_data"]=$this->Admin_data->subscribe_data();
	 	$this->load->view("Subscribe_view",$data);

	 }
	 
	 function Table()
	 {
	 	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');

	 if ($_POST) {
			$data=array(
           'title'=>$this->input->post('title'),
            'date'=>$this->input->post('date'),
           
            'hours'=>$this->input->post('hours'),
            'location'=>$this->input->post('location'),
            'spealist'=>$this->input->post('spealist'),
            'news'=>$this->input->post('news')
           

				 );
			$this->Admin_data->news_insert($data);


		}
		else{
		$this->load->view('Table_view');
	 }
	}

	function Logout(){
		session_start();
		unset($_SESSION['admin']);
		header('location:http://localhost/medical/index.php/Admin/Log');
	}

	function Delate($delete_id){
		$this->load->model('Admin_data');
	  $affected=$this->Admin_data->delete($delete_id);
	  if ($affected) header('location:http://localhost/medical/index.php/Admin');


	}
	function update(){
		$user_id = $this->uri->segment(3);
			$this->load->model('Admin_data');
			$data["user_data"]=$this->Admin_data->single_data($user_id);
			$data['fetch_data'] = $this->Admin_data->fetch_data();
			$this->load->view('update_view', $data);
	}
	function Unknown(){
		$Unknown["fetch_dat"]=$this->Admin_data->fetch_dat();
	 	$this->load->view("Unknown_view",$Unknown);

	}
	function Send (){
		$this->load->view('Send_view');

	}
	function send_sms(){
     
           $phone = $this->input->post('phone');
           $msg=$this->input->post('msg');
           

			
           

	// Authorisation details.
	$username = "priteshmuz37@gmail.com";
	$hash = "19b14a16747ee027a82c69c1042e0611213552c370922cfd31a71d6059284298";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "$phone"; // A single number or a comma-seperated list of numbers
	$message = "$msg";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);


	}

	function Doctors(){
		session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Admin/Log');
		$this->load->model('Admin_data');

	 	$data["doctor_data"]=$this->Admin_data->doctor_data();
	 	$this->load->view("Doctors_view",$data);
	
	}

	 function Delate_doctor($doctor_id){
	 	$this->load->model('Admin_data');
	  $affected=$this->Admin_data->delete_doctor($doctor_id);
	  if ($affected) header('location:http://localhost/medical/index.php/Admin/Doctors');

	 }

	
}



?>