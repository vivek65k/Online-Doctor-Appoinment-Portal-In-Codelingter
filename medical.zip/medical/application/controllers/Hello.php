<?php
/**
* 
*/
class Hello extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		
	

		$this->load->model('Data');

	}
	function index(){
		session_start();

		if (!isset($_SESSION['admin']))

		header('location:http://localhost/medical/index.php/Hello/Main');
		$this->load->model('Data');
		if ($_POST) {
			$data=array(
           'depart'=>$this->input->post('depart'),
            'Doctor'=>$this->input->post('Doctor'),
            'name'=>$this->input->post('name'),
            'number'=>$this->input->post('number')

				 );
			$this->Data->appoiment_insert($data);


		}
		else{
		$this->load->view('Hello_view');
	 }
	}
	function About(){
      session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Hello/Main');
		$this->load->model('Data');


		$this->load->view('about_view');
	}
	function Servics(){
		session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Hello/Main');
		$this->load->model('Data');
		$this->load->view('servics_view');
	}
	function News(){
		session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Hello/Main');
		$this->load->model('Data');

	 	$dta["fetch_data"]=$this->Data->fetch_data();
	 	$this->load->view("News_view",$dta);
	 }
		
	function Contact(){
		session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Hello/Main');
		$this->load->model('Data');
       if ($_POST) {
       	$dta=array(
       		'name'=>$this->input->post('name'),
      'email'=>$this->input->post('email'),
      'subject'=>$this->input->post('subject'),
      'msg'=>$this->input->post('msg')

     
       	);
       $this->Data->data_insert($dta);

       }else{

		$this->load->view('contect_view');
	 }
	}

    function Footer(){
    	session_start();
		if (!isset($_SESSION['admin']))
		header('location:http://localhost/medical/index.php/Hello/Main');
		$this->load->model('Data');
    	if ($_POST) {
    		
    		$dat=array(
             'subscribe'=>$this->input->post('subscribe')
    		);
    		$this->Data->insert_data($dat);
    	}
    	else{
    		$this->load->view('footer_view');
    	}

    }
	
	function Redirect(){
		$this->load->view('Redirect');
	}
	function Subscribe(){
		$this->load->view('Subscribe');
	}

	function Main(){
	if ($_POST) {
    		
    		$unknown=array(
    			'name'=>$this->input->post('name'),
    			'email'=>$this->input->post('email'),
    			'number'=>$this->input->post('number'),
    			'massage'=>$this->input->post('massage'),
          
    		);   
    		$this->Data->unknown_data($unknown);
    	}
    	else{
    		$this->load->view('Main_view');
    	}

    }
	
	function Login(){
			if ($_POST) {
    		
    		$singup=array(
             'username'=>$this->input->post('username'),
                        'email'=>$this->input->post('email'),
                              'password'=>$this->input->post('password')
    		);
    		$this->Data->singup_data($singup);
    	}
    	else{
    		$this->load->view('log_view');
    	}



		
	}
	function user_login(){
		$this->load->view('user_login.php');
	}
	function cheak_login(){
		$email=$this->input->post('email');
		$password=$this->input->post('password');

		$result=$this->Data->cheak_login($email,$password);
		if (count($result)==1) {
	
			session_start();

		
			$_SESSION['admin']=$result[0];
		
	
			header('location:http://localhost/medical/index.php/Hello');

		}
			else{
				echo "<script>alert('Email or password is incorrect,Please Try again...')</script> ";

		}

	}

	function Logout(){
		session_start();
		unset($_SESSION['admin']);
		header('location:http://localhost/medical/index.php/Hello/Main');
	}


     function showAllEmployee(){
		$result = $this->Data->showAllEmployee();
		echo json_encode($result);
			}


 

 
   function  appointment(){
   $dta["doctor_data"]=$this->Data->doctor_data();
	 	$this->load->view("appointment_view",$dta);
   }
	
	
	

}
?>