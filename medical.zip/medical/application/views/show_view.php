<table class="table table-bordered table-responsive" style="margin-top: 20px;">
		<thead>
			<tr>
				<td>ID</td>
				<td>Employee Name</td>
				<td>Address</td>
				<td>Created at</td>
				<td>Action</td>
			</tr>
		</thead>
		<tbody id="showdata">
			
		</tbody>
	</table>
	<script>
    $(function(){
        showAllEmployee();
        //function
        function showAllEmployee(){
            $.ajax({
                type: 'ajax',
                url: 'http://localhost/medical/index.php/Hello/showAllEmployee',
                async: false,
                dataType: 'json',
                success: function(data){

                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                    
                        html +='<tr>'+
                                    '<td>'+data[i].id+'</td>'+
                                    '<td>'+data[i].title+'</td>'+
                                    '<td>'+data[i].date+'</td>'+
                                    '<td>'+data[i].news+'</td>'+
                                    
                                    '<td>'+
                                        '<a href="javascript:;" class="btn btn-info item-edit" data="'+data[i].id+'">Edit</a>'+
                                        '<a href="javascript:;" class="btn btn-danger item-delete" data="'+data[i].id+'">Delete</a>'+
                                    '</td>'+
                                '</tr>';
                    }
                    $('#showdata').html(html);
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }
    });
</script>

