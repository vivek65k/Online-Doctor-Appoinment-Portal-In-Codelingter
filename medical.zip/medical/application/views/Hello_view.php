<!DOCTYPE html>
<html lang="en">
<head>
    <title>MEDArt</title>
    <link rel="shortcut icon" href="http://iconsetc.com/icons-watermarks/flat-circle-white-on-black/raphael/raphael_home/raphael_home_flat-circle-white-on-black_512x512.png" type="image/png">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/swiper.min.css ')?>">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css')?>">
    <script src="<?php echo base_url('assets/js/custom.js')?>"></script>

    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.1.1.min.js')?>"></script>

    <script src="//platform-api.sharethis.com/js/sharethis.js#property=5b798ff46fd7d20011419d7d&product=inline-share-buttons"></script>

     <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>     
</head>
<body>
    <header class="site-header">
        <div class="nav-bar">
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex flex-wrap justify-content-between align-items-center">
                        <div class="site-branding d-flex align-items-center">
                           <a class="d-block" href="index.html" rel="home"><img class="d-block" src="<?php echo base_url('assets/images/logo.png')?>" alt="logo"></a>
                          
                        </div><!-- .site-branding -->

                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-items-center">

                                <li class="current-menu-item"><a href="index.html">Home</a></li>
                                <li><a href="Hello/About">About us</a></li>
                                <li><a href="Hello/Servics">Services</a></li>
                                <li><a href="Hello/News">Doctors</a></li>
                                <li><a href="Hello/Contact">Contact</a></li>
                                   <li><a href="Hello/Logout">Logout</a></li>

                                <li class="call-btn button gradient-bg mt-3 mt-md-0">
                                    <a class="d-flex justify-content-center align-items-center" href="#"><img src="<?php echo base_url('assets/images/emergency-call.png')?>"> +91 8210991424 </a>
                                </li>
                            </ul>
                        </nav><!-- .site-navigation -->



                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->



        <div class="swiper-container hero-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide hero-content-wrap" style="background-image: url('<?php echo base_url('assets/images/hero.jpg')?>">
                    <div class="hero-content-overlay position-absolute w-100 h-100">
                        <div class="container h-100">
                            <div class="row h-100">
                                <div class="col-12 col-lg-6 d-flex flex-column justify-content-center align-items-start">
                                    <header class="entry-header">
                                        <h1>The Best <br>Medical Services</h1>
                                    </header><!-- .entry-header -->

                                    <div class="entry-content mt-4">
                                        <p>MEDArt has once again been recognized for our exceptional care, unmatched expertise and continued excellence. With the most nationally ranked specialties in Indiana, IU Health is the name Indiana trusts for healthcare.</p>
                                    </div><!-- .entry-content -->

                                    <footer class="entry-footer d-flex flex-wrap align-items-center mt-4">
                                        <a href="#" class="button gradient-bg">Read More</a>
                                    </footer><!-- .entry-footer -->
                                </div><!-- .col -->
                            </div><!-- .row -->
                        </div><!-- .container -->
                    </div><!-- .hero-content-overlay -->
                </div><!-- .hero-content-wrap -->




                <div class="swiper-slide hero-content-wrap" style="background-image: url(<?php echo base_url('assets/images/hero.jpg')?>">
                    <div class="hero-content-overlay position-absolute w-100 h-100">
                        <div class="container h-100">
                            <div class="row h-100">
                                <div class="col-12 col-lg-6 d-flex flex-column justify-content-center align-items-start">
                                    <header class="entry-header">
                                        <h1>The Best <br>Medical Services</h1>
                                    </header><!-- .entry-header -->

                                    <div class="entry-content mt-4">
                                        <p>Lorem ipsum dolor sit ametelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus.</p>
                                    </div><!-- .entry-content -->

                                    <footer class="entry-footer d-flex flex-wrap align-items-center mt-4">
                                        <a href="#" class="button gradient-bg">Read More</a>
                                    </footer><!-- .entry-footer -->
                                </div><!-- .col -->
                            </div><!-- .row -->
                        </div><!-- .container -->
                    </div><!-- .hero-content-overlay -->
                </div><!-- .hero-content-wrap -->




                <div class="swiper-slide hero-content-wrap" style="background-image: url('images/hero.jpg')">
                    <div class="hero-content-overlay position-absolute w-100 h-100">
                        <div class="container h-100">
                            <div class="row h-100">
                                <div class="col-12 col-lg-6 d-flex flex-column justify-content-center align-items-start">
                                    <header class="entry-header">
                                        <h1>The Best <br>Medical Services</h1>
                                    </header><!-- .entry-header -->

                                    <div class="entry-content mt-4">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus.</p>
                                    </div><!-- .entry-content -->

                                    <footer class="entry-footer d-flex flex-wrap align-items-center mt-4">
                                        <a href="#" class="button gradient-bg">Read More</a>
                                    </footer><!-- .entry-footer -->
                                </div><!-- .col -->
                            </div><!-- .row -->
                        </div><!-- .container -->
                    </div><!-- .hero-content-overlay -->
                </div><!-- .hero-content-wrap -->
            </div><!-- .swiper-wrapper -->
            <div class="sharethis-inline-share-buttons"></div>

            <div class="pagination-wrap position-absolute w-100">
                <div class="swiper-pagination d-flex flex-row flex-md-column"></div>
            </div><!-- .pagination-wrap -->
        </div><!-- .hero-slider -->
    </header><!-- .site-header -->

   


 <?php

 $this->load->view('appointment_view');
 ?>





   
    <div style=" margin-bottom: 20px;">
     <div class="sharethis-inline-share-buttons"></div>
 </div>
    <div class="our-departments">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="our-departments-wrap">
                        <h2>Our Departments</h2>

                        <div class="row">
                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/cardiogram.png" alt="">

                                        <h3>Cardioology</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>Here Doctors is very well but their staff behavior isn't well, Patient & with attender dose not found many  department , they are not right information about the hospital, didn't mention anything about this hospital guidance,  not found any other questions please feel kindly help our patients, this hospital is very crowded but their are not toilets in used to patient, Many pay & use toilets are available, this my short experience about this hospita.</p>
                                    </div>
                                      <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/stomach-2.png" alt="">

                                        <h3>Gastroenterology</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>Gastroesophageal reflux disease (GERD) is more than just heartburn. GERD is when stomach acid flows back up (refluxes) into the esophagus chronically. If left untreated, it can lead to Barrett’s esophagus, a condition that destroys the esophagus’ lining and can lead to esophageal cancer</p>
                                    </div>
                                  <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/blood-sample-2.png" alt="">

                                        <h3>Medical Lab</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>We combine compassion and unwavering commitment to your needs with truly state-of-the-art surgical capabilities and know-how, including performing procedures offered few other places in North Texas. In addition, we are uncommonly thorough and detailed, affiliated with top hospitals, and able to handle even the most complex surgical cases. Because you deserve nothing less.</p>
                                    </div>
                                    <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/teeth.png" alt="">

                                        <h3>Dental Care</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>Surgery is an important treatment for cancer, and often the first treatment for many people with cancer. It can be used to remove tumors as part of an overall plan to cure cancer. Surgery is also often used to relieve pain and improve quality of life for cancer patients.</p>
                                    </div>
                                    <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/stretcher.png" alt="">

                                        <h3>Surgery</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>Surgery is an important treatment for cancer, and often the first treatment for many people with cancer. It can be used to remove tumors as part of an overall plan to cure cancer. Surgery is also often used to relieve pain and improve quality of life for cancer patients.

Cancer surgery is always important and often varied, complex and challenging. NTSOA surgeons meet these challenges with the vast experience and state-of-the-art capabilities trusted by patients and doctors throughout North Texas.</p>
                                    </div>
                                    <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/scanner.png" alt="">

                                        <h3>Neurology</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>Cancer surgery is always important and often varied, complex and challenging. NTSOA surgeons meet these challenges with the vast experience and state-of-the-art capabilities trusted by patients and doctors throughout North Texas.
                               
</p>
                                    </div>
                                    <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4 mb-md-0">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/bones.png" alt="">

                                        <h3>Orthopaedy</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>At NTSOA, Dr. Smith and Dr. Le Voyer bring the same skill, compassion and attention to detail to general surgical procedures as they do to cancer surgeries. In addition to their excellent general surgery training, both doctors performed surgeries in and out of combat for the military and for years since leaving service. As a result, they’ve been exposed to all sorts of surgical situations, including the high-pressure, high-stakes challenges of trauma.</p>
                                    </div>
                                    <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4 mb-lg-0">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/blood-donation-2.png" alt="">

                                        <h3>Pediatry</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>To ensure you get the best possible outcomes, our surgeons use today’s most advanced, minimally invasive techniques and leading-edge technology. In fact, Drs. Smith and Le Voyer are innovators and pioneers of surgery in North Texas. We were the first practice in the region to perform the LINX procedure for reflux and to use state-of-the-art NanoKnife for pancreatic surgery. We are one of the few practices in Texas that perform Robotics/minimally invasive highly complex gastrointestinal surgery. Overall, we've trailblazed the use of several sophisticated surgeries in our area… with the high degree of competence and experience doctors and patients count on.</p>
                                    </div>
                                 <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>

                            <div class="col-12 col-md-6 col-lg-4 mb-0">
                                <div class="our-departments-cont">
                                    <header class="entry-header d-flex flex-wrap align-items-center">
                                        <img src="images/glasses.png" alt="">

                                        <h3>Ophthalmology</h3>
                                    </header>

                                    <div class="entry-content">
                                        <p>As surgeons, we are an important part of your overall medical team, dedicated to the quality and continuity of your care. We work with your other doctors — oncologists, gastroenterologists, nephrologists, primary care physicians, etc. — to provide the best possible surgical outcomes...and then to get you back into their care. Realizing that it is a stressful time for anyone, our goal is to make coordination of your care as least burdensome on you as possible.</p>
                                    </div>
                                    <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

                                    <footer class="entry-footer">
                                        <a href="#">read more</a>
                                    </footer>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="testimonial-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Pacient’s Testimonials</h2>
                </div>
            </div>
        </div>

        <!-- Swiper -->
        <div class="testimonial-slider">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-9">
                        <div class="testimonial-bg-shape">
                            <div class="swiper-container testimonial-slider-wrap">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="entry-content">
                                            <p>Simply put, continuity of care has to do with the quality, consistency and efficacy of your medical care over time. In the care of your health, many different medical professionals are likely to be involved, and you can count on it if you are diagnosed with a serious medical condition, which of course includes cancer.</p>
                                        </div><!-- .entry-content -->

                                        <div class="entry-footer">
                                            <figure class="user-avatar">
                                                <img src="<?php echo base_url('assets/images/user-1.jpg ')?>" alt="">
                                            </figure><!-- .user-avatar -->

                                            <h3 class="testimonial-user">Vivek Pandey <span>Techno India ,Hooghly</span></h3>
                                        </div><!-- .entry-footer -->
                                    </div><!-- .swiper-slide -->

                                    <div class="swiper-slide">
                                        <div class="entry-content">
                                            <p>Simply put, continuity of care has to do with the quality, consistency and efficacy of your medical care over time. In the care of your health, many different medical professionals are likely to be involved, and you can count on it if you are diagnosed with a serious medical condition, which of course includes cancer.</p>
                                        </div><!-- .entry-content -->

                                        <div class="entry-footer">
                                            <figure class="user-avatar">
                                                <img src=" <?php echo base_url('assets/images/user-2.jpg')?>" alt="">
                                            </figure><!-- .user-avatar -->

                                            <h3 class="testimonial-user">Susmita Sen<span>Techno India ,Hooghly</span></h3>
                                        </div><!-- .entry-footer -->
                                    </div><!-- .swiper-slide -->

                                    <div class="swiper-slide">
                                        <div class="entry-content">
                                            <p>As cancer surgical oncologists, we see our role as one of coordinating the management of your care as it relates to surgery. To put it another way, we believe it is our responsibility to cooperate openly, honestly and actively as part of your overall cancer team. But at the same time, we see ourselves as having a duty to take over the coordination of your care and ensuring all your needs are met if that coordination isn’t already being handled.</p>
                                        </div><!-- .entry-content -->

                                        <div class="entry-footer">
                                            <figure class="user-avatar">
                                                <img src="<?php echo base_url('assets/images/user-3.jpg')?>" alt="">
                                            </figure><!-- .user-avatar -->

                                            <h3 class="testimonial-user">Arghya Bhattacharya <span>University in UK</span></h3>
                                        </div><!-- .entry-footer -->
                                    </div><!-- .swiper-slide -->

                                    <div class="swiper-slide">
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Curabitur ut augue finibus, luctus tortor at, ornare erat. Nulla facilisi. Sed est risus, laoreet et quam non, viverra accumsan leo.</p>
                                        </div><!-- .entry-content -->

                                        <div class="entry-footer">
                                            <figure class="user-avatar">
                                                <img src="images/user-4.jpg" alt="">
                                            </figure><!-- .user-avatar -->

                                            <h3 class="testimonial-user">Russell Stephens <span>University in UK</span></h3>
                                        </div><!-- .entry-footer -->
                                    </div><!-- .swiper-slide -->
                                </div><!-- .swiper-wrapper -->

                                <div class="swiper-pagination-wrap">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="swiper-pagination position-relative flex justify-content-center align-items-center"></div>
                                            </div><!-- .col -->
                                        </div><!-- .row -->
                                    </div><!-- .container -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .testimonial-slider -->
    </section><!-- .testimonial-section -->


<div class="sharethis-inline-share-buttons"></div>


    <div class="the-news">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>The News</h2>

                    <div class="row">
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="the-news-wrap">
                                <figure class="post-thumbnail">
                                    <a href="#"><img src="<?php echo base_url('assets/images/news-1.png')?>" alt=""></a>
                                </figure>

                                <header class="entry-header">
                                    <h3>New findings concerning hereditary prostate cancer</h3>

                                    <div class="post-metas d-flex flex-wrap align-items-center">
                                        <div class="posted-date"><label>Date: </label><a href="#">April 12, 2018</a></div>

                                        <div class="posted-by"><label>By: </label><a href="#">Dr. Vivek Kumar Pandey</a></div>

                                        <div class="post-comments"><a href="#">2 Comments</a></div>
                                    </div>
                                </header>

                                <div class="entry-content">
                                    <p>It is a well-known fact that men with a family history of prostate cancer run an increased risk of developing the disease. The risk for brothers of men with prostate cancer is doubled. But a doubled risk of what, exactly? Prostate cancer my be an indolent condition that does not require treatment, or aggressive and fatal. Obviously, it makes a big difference whether a man has an increased risk of developing the indolent or the aggressive form, but until now these different risks have not been known. </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="the-news-wrap">
                                <figure class="post-thumbnail">
                                    <a href="#"><img src=" <?php echo base_url('assets/images/news-2.png')?>" alt=""></a>
                                </figure>

                                <header class="entry-header">
                                    <h3>All you need to know about pills</h3>

                                    <div class="post-metas d-flex flex-wrap align-items-center">
                                        <div class="posted-date"><label>Date: </label><a href="#">April 12, 2018</a></div>

                                        <div class="posted-by"><label>By: </label><a href="#">Dr. Susmita Sen</a></div>

                                        <div class="post-comments"><a href="#">4 Comments</a></div>
                                    </div>
                                </header>

                                <div class="entry-content">
                                    <p>While many cancer therapies initially can be very successful, tumors often return and spread when remaining cancer cells develop resistance to treatment. To combat this tendency, cancer researchers could take a lesson from our own immune system and explore 'natural adaptive therapies,' according to a new article. </p>

                            </div>
                        </div>

                      </div>
               


                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="the-news-wrap">
                                <figure class="post-thumbnail">
                                    <a href="#"><img src="<?php echo base_url('assets/images/news-3.png ')?>" alt=""></a>
                                </figure>

                                <header class="entry-header">
                                    <h3>TIH, Health Sciences Campus</h3>

                                    <div class="post-metas d-flex flex-wrap align-items-center">
                                        <div class="posted-date"><label>Date: </label><a href="#">April 12, 2018</a></div>

                                        <div class="posted-by"><label>By: </label><a href="#">Dr. Arghya Bhattacharya</a></div>

                                        <div class="post-comments"><a href="#">2 Comments</a></div>
                                    </div>
                                </header>

                                <div class="entry-content">
                                    <p>A new cost-effectiveness study estimates that nearly one million cardiovascular and diabetes events could be prevented and $42 billion could be saved in healthcare costs by including food incentives and disincentives for participants on SNAP. Of three models, two were cost-effective but the third, SNAP-plus, was not only cost-effective but actually cost-saving -- i.e., the government gained more dollars than it spent -- with net cost-savings of $10.16 billion at five years and $63.33 billion over lifetime. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.2&appId=452711395175318&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>



<div style="margin-left: 300px; margin-bottom: 20px; margin-top: 20px; "  >      


<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2F20531316728%2Fposts%2F10154009990506729%2F&width=500&show_text=true&appId=452711395175318&height=290" width="500" height="290" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>




    </div>

    
        
<script>
    $(function(){
        showAllEmployee();
        //function
        function showAllEmployee(){
            $.ajax({
                type: 'ajax',
                url: 'http://localhost/medical/index.php/Hello/showAllEmployee',
                async: false,
                dataType: 'json',
                success: function(data){

                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                    
                        html +='<tr>'+
                                  
                                    '<td>'+data[i].title+'</td>'+ 
                                    
                                  
                                    
                                   
                                '</tr>';
                    }
                    $('#showdata').html(html);
                },
                error: function(){
                    alert('Could not get Data from Database');
                }
            });
        }
    });
</script>


    
   
 
 <?php

 $this->load->view('footer_view');
 ?>