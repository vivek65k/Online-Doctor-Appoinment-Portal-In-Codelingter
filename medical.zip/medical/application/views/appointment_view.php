

 <div class="homepage-boxes">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="opening-hours">
                        <h2 class="d-flex align-items-center">Opening Hours</h2>

                        <ul class="p-0 m-0">
                            <li>Monday - Thursday <span>8.00 - 19.00</span></li>
                            <li>Friday <span>8.00 - 18.30</span></li>
                            <li>Saturday <span>9.30 - 17.00</span></li>
                            <li>Sunday <span>9.30 - 15.00</span></li>
                        </ul>
                    </div>
                </div>

                <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0" style="width: 20px; ">
                    <div class="emergency-box">
                        <h2 class="d-flex align-items-center">Emergency</h2>

                        <div class="call-btn button gradient-bg">
                            <a class="d-flex justify-content-center align-items-center" href="#"><img src="<?php echo base_url('assets/images/emergency-call.png')?>"> +91 8210991424</a>
                        </div>

                        <p>MEDArt has once again been recognized for our exceptional care, unmatched expertise and continued excellence.</p>
                    </div>
                </div>
                         <div class="col-12 col-md-6 col-lg-5 mt-5 mt-lg-0">
                    <div class="appointment-box">
                        <h2 class="d-flex align-items-center">Make an Appointment</h2>

                        <form class="d-flex flex-wrap justify-content-between" method="post" action="Hello">
                            <select class="select-department" name="depart">
                                <option value="value1">Radiology</option>
                                <option value="value2">Cardiology</option>
                                <option value="value3">Gastroenterology</option>
                                    <option value="value3">Neurology</option>
                                        <option value="value3">General surgery</option>
                            </select>

                            <select class="select-doctor"  name="Doctor">
                                <option>Dr Sanshaptak Ghosh</option>
                                <option>Dr. A.B.Saha</option>
                                <option>Dr Dipanjan Saha</option>
                                   <option>Dr Dipanjan Saha</option>
                                      <option>Dr S Kar</option>
                                         <option>Dr Abhijit Ray</option>
                                            <option>Dr H S Pathak</option>
                                               <option>Dr B Mukherjee</option>
                                                  <option>Dr.Goutam Kumar </option>
                                                  <option>Dr Subrata Ghosh</option>
                                                  <option>Dr Arnab Gangopadhyay</option>
                                                  <option>Dr Arkajyoti Mallick</option>
                            </select>

                            <input type="text" name="name" placeholder="Name">

                            <input type="number" name="number" placeholder="Phone No">

                            <input class="button gradient-bg" type="submit" name="submit" value="Boom Appoitnment">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
