

<div class="subscribe-banner">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-8 offset-lg-2">
                    <h2>Subscribe to our newsletter</h2>
                    <div class="sharethis-inline-follow-buttons"></div>

                    <form method="post" action="http://localhost/medical/index.php/Hello/Footer">
                        <input type="email" name="subscribe" placeholder="E-mail address">
                        <input class="button gradient-bg" type="submit" value="Subscribe">
                    </form>
                </div>
            </div>
        </div>
    </div>


 <footer class="site-footer">
        <div class="footer-widgets">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="foot-about">
                            <h2><a href="#"><img src="<?php echo base_url('assets/images/logo.png')?>" alt=""></a></h2>

                            <p>MEDArt has once again been recognized for our exceptional care, unmatched expertise and continued excellence. With the most nationally ranked specialties in Indiana, IU Health is the name Indiana trusts for healthcare.</p>

                            <p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="#" target="_blank">Vivek Kumar Pandey</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div><!-- .foot-about -->
                    </div><!-- .col -->

                    <div class="col-12 col-md-6 col-lg-4 mt-5 mt-md-0">
                        <div class="foot-contact">
                            <h2>Contact</h2>

                            <ul class="p-0 m-0">
                                <li><span>Addtress:</span>Chinsurah  Hooghly KOLKATA INDIA</li>
                                <li><span>Phone:</span>+91 8210991424 </li>
                                <li><span>Email:</span>vivek65k@gmail.com</li>
                            </ul>
                        </div>
                    </div><!-- .col -->

                    <div class="col-12 col-md-6 col-lg-4 mt-5 mt-md-0">
                        <div class="foot-links">
                            <h2>Usefull Links</h2>

                            <ul class="p-0 m-0">
                                <li><a href="index.html">Home</a></li>
                                <li><a href="about.html">About us</a></li>
                                <li><a href="#">Departments</a></li>
                                <li><a href="contact.html">Contact</a></li>
                                <li><a href="news.html">FAQ</a></li>
                                <li><a href="services.html">Testimonials</a></li>
                            </ul>
                        </div><!-- .foot-links -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .footer-widgets -->
    </footer><!-- .site-footer -->

    <script type='text/javascript' src='<?php echo base_url('assets/js/jquery.js')?>'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/js/jquery.collapsible.min.js')?>'></script>
    <script type='text/javascript' src='<?php base_url('assets/js/swiper.min.js')?>'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/js/jquery.countdown.min.js')?>'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/js/circle-progress.min.js')?>'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/js/jquery.countTo.min.js')?>'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/js/jquery.barfiller.js')?>'></script>
    <script type='text/javascript' src='<?php echo base_url('assets/js/custom.js')?>'></script>
</body>
</html>