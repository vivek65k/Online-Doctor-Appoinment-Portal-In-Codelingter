<!DOCTYPE html>
<html>
<head>
	<title>Send Massage</title>
	 <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">

	 <style>
	 	 body{
	 	 	background: url(http://gutaid.com/wp-content/uploads/2015/05/background.jpg);
	 	 }

	 </style>

</head>
<body>
	<div style="width: 600px; margin-top: 100px; margin-left: 400px;" >
	<form method="post" action="send_sms" >

		<h1>Appointment Letter </h1>
		<hr>
  <div class="form-group">
    <label for="exampleInputEmail1">Enter the number</label>
    <input type="number" name="phone" class="form-control" id="exampleInputEmail1" placeholder="Phone Number">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Write a massage</label>
    <input type="text" name="msg" class="form-control" id="exampleInputPassword1" placeholder="Enter a massage">
  </div>
  
  <input type="submit" name="submit" value="send" class="btn btn-default">
</form>

</body>
</html>