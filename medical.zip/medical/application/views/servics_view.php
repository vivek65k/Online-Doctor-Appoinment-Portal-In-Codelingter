<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hello World</title>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/swiper.min.css')?>">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css')?>">
</head>
<body class="single-page">
    <header class="site-header">
        <div class="nav-bar">
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex flex-wrap justify-content-between align-items-center">
                        <div class="site-branding d-flex align-items-center">
                            <a class="d-block" href="index.html" rel="home"><img class="d-block" src="<?php echo base_url('assets/images/logo.png')?>" alt="logo"></a>
                        </div><!-- .site-branding -->

                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-items-center">
                                <li class="current-menu-item"><a href="http://localhost/medical/index.php/Hello">Home</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/About">About us</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/Services">Services</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/News">Doctors</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/Contact">Contact</a></li>

                                <li class="call-btn button gradient-bg mt-3 mt-md-0">
                                    <a class="d-flex justify-content-center align-items-center" href="#"><img src="<?php echo base_url('assets/images/emergency-call.png')?>"> +91 8210991424</a>
                                </li>
                            </ul>
                        </nav><!-- .site-navigation -->

                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Services</h1>

                    <div class="breadcrumbs">
                        <ul class="d-flex flex-wrap align-items-center p-0 m-0">
                            <li><a href="#">Home</a></li>
                            <li>Services</li>
                        </ul>
                    </div><!-- .breadcrumbs -->
                </div>
            </div>
        </div>

        <img class="header-img" src="<?php echo base_url('assets/images/service-bg.png')?>" alt="">
    </header><!-- .site-header -->

    <div class="quality-services">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Only Top Quality Services</h2>

                    <div class="row">
                        <div class="col-12 col-md-6">
                            <p>MEDArt has once again been recognized for our exceptional care, unmatched expertise and continued excellence. With the most nationally ranked specialties in Indiana, IU Health is the name Indiana trusts for healthcare.</p>
                        </div>

                        <div class="col-12 col-md-6">
                            <p>Getting effective treatment depends on identifying the right problem. In a recent study, 88 percent of patients who came to Mayo Clinic for a second opinion received a new or refined diagnosisa.</p>
                        </div>
                    </div>

                    <div class="w-100 text-center mt-5">
                        <a class="button gradient-bg" href="#">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="our-departments-wrap">
                    <h2>Our Departments</h2>

                    <div class="row">
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/cardiogram.png" alt="">

                                    <h3>Cardioology</h3>
                                </header>

                                <div class="entry-content">
                                    <p>Here Doctors is very well but their staff behavior isn't well, Patient & with attender dose not found many  department , they are not right information about the hospital, didn't mention anything about this hospital guidance,  not found any other questions please feel kindly help our patients, this hospital is very crowded but their are not toilets in used to patient, Many pay & use toilets are available, this my short experience about this hospita.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/stomach-2.png" alt="">

                                    <h3>Gastroenterology</h3>
                                </header>

                                <div class="entry-content">
                                    <p>Gastroesophageal reflux disease (GERD) is more than just heartburn. GERD is when stomach acid flows back up (refluxes) into the esophagus chronically. If left untreated, it can lead to Barrett’s esophagus, a condition that destroys the esophagus’ lining and can lead to esophageal cancer.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/blood-sample-2.png" alt="">

                                    <h3>Medical Lab</h3>
                                </header>

                                <div class="entry-content">
                                    <p>We combine compassion and unwavering commitment to your needs with truly state-of-the-art surgical capabilities and know-how, including performing procedures offered few other places in North Texas. In addition, we are uncommonly thorough and detailed, affiliated with top hospitals, and able to handle even the most complex surgical cases. Because you deserve nothing less.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/teeth.png" alt="">

                                    <h3>Dental Care</h3>
                                </header>

                                <div class="entry-content">
                                    <p>Surgery is an important treatment for cancer, and often the first treatment for many people with cancer. It can be used to remove tumors as part of an overall plan to cure cancer. Surgery is also often used to relieve pain and improve quality of life for cancer patients.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/stretcher.png" alt="">

                                    <h3>Surgery</h3>
                                </header>

                                <div class="entry-content">
                                    <p>Surgery is an important treatment for cancer, and often the first treatment for many people with cancer. It can be used to remove tumors as part of an overall plan to cure cancer. Surgery is also often used to relieve pain and improve quality of life for cancer patients.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/scanner.png" alt="">

                                    <h3>Neurology</h3>
                                </header>

                                <div class="entry-content">
                                    <p>Cancer surgery is always important and often varied, complex and challenging. NTSOA surgeons meet these challenges with the vast experience and state-of-the-art capabilities trusted by patients and doctors throughout North Texas.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4 mb-md-0">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/bones.png" alt="">

                                    <h3>Orthopaedy</h3>
                                </header>

                                <div class="entry-content">
                                    <p>At NTSOA, Dr. Smith and Dr. Le Voyer bring the same skill, compassion and attention to detail to general surgical procedures as they do to cancer surgeries. In addition to their excellent general surgery training, both doctors performed surgeries in and out of combat for the military and for years since leaving service.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4 mb-lg-0">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/blood-donation-2.png" alt="">

                                    <h3>Pediatry</h3>
                                </header>

                                <div class="entry-content">
                                    <p>To ensure you get the best possible outcomes, our surgeons use today’s most advanced, minimally invasive techniques and leading-edge technology. In fact, Drs. Smith and Le Voyer are innovators and pioneers of surgery in North Texas. We were the first practice in the region to perform the LINX procedure for reflux and to use state-of-the-art NanoKnife for pancreatic surgery.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-4 mb-0">
                            <div class="our-departments-cont">
                                <header class="entry-header d-flex flex-wrap align-items-center">
                                    <img src="images/glasses.png" alt="">

                                    <h3>Ophthalmology</h3>
                                </header>

                                <div class="entry-content">
                                    <p>As surgeons, we are an important part of your overall medical team, dedicated to the quality and continuity of your care. We work with your other doctors — oncologists, gastroenterologists, nephrologists, primary care physicians, etc. — to provide the best possible surgical outcomes.</p>
                                     <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&layout=button_count&size=large&mobile_iframe=true&appId=452711395175318&width=106&height=28" width="106" height="28" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                </div>

                                <footer class="entry-footer">
                                    <a href="#">read more</a>
                                </footer>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="services-tabs">
                    <div class="tabs">
                        <ul class="tabs-nav d-flex flex-wrap">
                            <li class="tab-nav d-flex justify-content-center align-items-center" data-target="#tab_1">Pellentesque pulvinar</li>
                            <li class="tab-nav d-flex justify-content-center align-items-center" data-target="#tab_2">  Pellentesque lacinia </li>
                            <li class="tab-nav d-flex justify-content-center align-items-center" data-target="#tab_3">Consectetur diam</li>
                            <li class="tab-nav d-flex justify-content-center align-items-center" data-target="#tab_4">CMauris tortor</li>
                            <li class="tab-nav d-flex justify-content-center align-items-center" data-target="#tab_5">Phasellus sit amet</li>
                        </ul>

                        <div class="tabs-container">
                            <div id="tab_1" class="tab-content">
                                <img src="images/service-tab-img.png" alt="">

                                <h4>Scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. </h4>

                                <p>Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Curabitur ut augue finibus, luctus tortor at, ornare erat. Nulla facilisi. Sed est risus, laoreet et quam non, viverra accumsan leo. Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus</p>
                            </div>

                            <div id="tab_2" class="tab-content">
                                <img src="images/service-tab-img.png" alt="">

                                <h4>Scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. </h4>

                                <p>Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Curabitur ut augue finibus, luctus tortor at, ornare erat. Nulla facilisi. Sed est risus, laoreet et quam non, viverra accumsan leo. Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus</p>
                            </div>

                            <div id="tab_3" class="tab-content">
                                <img src="images/service-tab-img.png" alt="">

                                <h4>Scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. </h4>

                                <p>Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Curabitur ut augue finibus, luctus tortor at, ornare erat. Nulla facilisi. Sed est risus, laoreet et quam non, viverra accumsan leo. Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus</p>
                            </div>

                            <div id="tab_4" class="tab-content">
                                <img src="images/service-tab-img.png" alt="">

                                <h4>Scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. </h4>

                                <p>Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Curabitur ut augue finibus, luctus tortor at, ornare erat. Nulla facilisi. Sed est risus, laoreet et quam non, viverra accumsan leo. Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus</p>
                            </div>

                            <div id="tab_5" class="tab-content">
                                <img src="images/service-tab-img.png" alt="">

                                <h4>Scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. </h4>

                                <p>Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Curabitur ut augue finibus, luctus tortor at, ornare erat. Nulla facilisi. Sed est risus, laoreet et quam non, viverra accumsan leo. Amet, consectetur adipiscing elit. Donec malesuada lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien. Suspendisse cursus faucibus finibus</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div style="margin-left: 300px;  margin-bottom: 40px; ">
        
    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fhostprograming65%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=452711395175318" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>


    </div>

   <?php

 $this->load->view('footer_view');
 ?>