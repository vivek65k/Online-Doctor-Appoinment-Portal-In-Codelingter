<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctors</title>
        <link rel="shortcut icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiDK9CMjqpFYjnhwIv578na2_NaHREXRpnGXmTfGGyUW7tvirb" type="image/png">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/swiper.min.css')?>">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo base_url('assets/style.css')?>">
    <script src="//platform-api.sharethis.com/js/sharethis.js#property=5b798ff46fd7d20011419d7d&product=inline-share-buttons"></script>
</head>
<body class="single-page blog-page">




    <header class="site-header">
        <div class="nav-bar">
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex flex-wrap justify-content-between align-items-center">
                        <div class="site-branding d-flex align-items-center">
                            <a class="d-block" href="index.html" rel="home"><img class="d-block" src="<?php echo base_url('assets/images/logo.png')?>" alt="logo"></a>
                        </div><!-- .site-branding -->

                        <nav class="site-navigation d-flex justify-content-end align-items-center">
                            <ul class="d-flex flex-column flex-lg-row justify-content-lg-end align-items-center">
                                <li class="current-menu-item"><a href="http://localhost/medical/index.php/Hello">Home</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/About">About us</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/Servics">Service</a></li>
                                <li><a href="#">Doctors</a></li>
                                <li><a href="http://localhost/medical/index.php/Hello/Contact">Contact</a></li>

                                <li class="call-btn button gradient-bg mt-3 mt-md-0">
                                    <a class="d-flex justify-content-center align-items-center" href="#"><img src="<?php echo base_url('assets/images/emergency-call.png')?>"> +91 8210991424</a>
                                </li>
                            </ul>
                        </nav><!-- .site-navigation -->

                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </div><!-- .col -->
                </div><!-- .row -->
            </div><!-- .container -->
        </div><!-- .nav-bar -->

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1>Doctors</h1>

                    <div class="breadcrumbs">
                        <ul class="d-flex flex-wrap align-items-center p-0 m-0">
                            <li><a href="#">Home</a></li>
                            <li>Doctors</li>
                        </ul>
                    </div><!-- .breadcrumbs -->
                </div>
            </div>
        </div>

        <img class="header-img" src="<?php echo base_url('assets/images/news-bg.png')?>" alt="">
    </header><!-- .site-header -->

<div class="sharethis-inline-share-buttons"></div>
      <div class="container">
        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="the-news">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="the-news-wrap">
                                <figure class="post-thumbnail">
                                    <a href="#"><img src="images/news-1.png" alt=""></a>
                                </figure>
                                <?php
            if ($fetch_data->num_rows()>0) {
     
            foreach ($fetch_data->result() as $row) {
            ?>

                                <header class="entry-header">
                                    <h3><?php echo $row->title; ?></h3>

                                    <div class="post-metas d-flex flex-wrap align-items-center">
                                        <div class="posted-date"><label>Date: </label><a href="#"><?php echo $row->date; ?> </a></div>

                                        <div class="posted-by"><label>Hours:<?php echo $row->hours; ?> </label><a href="#"></a></div>

                                        <div class="post-comments"><a href="#"><?php echo $row->spealist;?></a></div>
                                    </div>
                                </header>

                                <div class="entry-content">
                                    <p><?php echo $row->news; ?> </p>
                                </div>

                                <footer class="entry-footer mt-5">
                                    <a class="button gradient-bg" href="http://localhost/medical/index.php/Hello">Get  Appointment</a>
                                </footer>
                                 <br>
                                <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2Fplugins%2F&width=450&layout=standard&action=recommend&size=large&show_faces=true&share=true&height=80&appId=452711395175318" width="450" height="80" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                <hr>
                                  <?php
     }
 }
 else{
    ?>
    <td> no comntent</td>   

      
    <?php
    }
    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <div style="margin-left: 100px; margin-bottom: 30px;">

<iframe src="https://www.facebook.com/plugins/comment_embed.php?href=https%3A%2F%2Fwww.facebook.com%2Fzuck%2Fposts%2F10102577175875681%3Fcomment_id%3D1193531464007751%26reply_comment_id%3D654912701278942&width=560&include_parent=false&appId=452711395175318&height=135" width="560" height="135" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
<div>




    
            <div class="col-12 col-lg-4" style="float: right; margin-top: -130%">
                <div class="sidebar">
                  

                    <div class="sidebar-cats">
                        <h2 class="widget-title">Categories</h2>

                        <ul class="p-0 m-0">
                            <li><a href="#">Radiology</a></li>
                            <li><a href="#">Cardiology</a></li>
                            <li><a href="#">Gastroenterology</a></li>
                            <li><a href="#">Neurology</a></li>
                            <li><a href="#">General surgery</a></li>
                        </ul>
                    </div>

                   

                    <div class="opening-hours">
                        <h2 class="d-flex align-items-center">Opening Hours</h2>

                        <ul class="p-0 m-0">
                            <li>Monday - Thursday <span>8.00 - 19.00</span></li>
                            <li>Friday <span>8.00 - 18.30</span></li>
                            <li>Saturday <span>9.30 - 17.00</span></li>
                            <li>Sunday <span>9.30 - 15.00</span></li>
                        </ul>
                    </div>

                    <div class="emergency-box">
                        <h2 class="d-flex align-items-center">Emergency</h2>

                        <div class="call-btn text-center">
                            <a class="d-flex justify-content-center align-items-center button gradient-bg" href="#"><img src="<?php echo base_url('assets/images/emergency-call.png')?>"> +91 8210991424</a>
                        </div>

                        <p>MEDArt has once again been recognized for our exceptional care, unmatched expertise and continued excellence.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
     <?php

 $this->load->view('footer_view');
 ?>