<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link href="<?php echo base_url('admin/vendor/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
</head>
<body>
	
	 		<div style=" width: 600px; margin-left: 400px; margin-top: 100px; ">
    <form>
	 <h1>Update Record </h1>
	 <hr>

 <?php 
	 if(isset($user_data)) {
	 	foreach($user_data as $row) 
	 	 {
	 		?>

  <div class="form-group">

    <label for="exampleInputEmail1">Email address</label>
    <input type="text" class="form-control" value="<?php echo $row->depart; ?>" id="exampleInputEmail1" placeholder="Email">
  </div>
   <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="text" value="<?php echo $row->depart; ?>"  class="form-control" id="exampleInputEmail1" placeholder="Email">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="text" value="<?php echo $row->Doctor; ?>" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  
  <input type="submit" name="submit"  value="update" class="btn btn-default">
  <?php  
	 	}
	 }
 
	 ?>
  </form>
</div>

	
</body>
</html>