-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 27, 2019 at 01:40 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `medart`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `depart` varchar(100) NOT NULL,
  `Doctor` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `depart`, `Doctor`, `name`, `number`) VALUES
(6, 'MedArt Clinic Children''s Center', 'Dr Tapan Khan Kr', 'Pritesh Thakur', '8210991424'),
(8, 'MedArt Clinic in Florida', 'Dr Tapan Khan Kr', 'HostPrograming', '8294862785'),
(9, 'MedArt Clinic in Florida', 'AyurHealing (Dr. Jyoti Lakhani)', 'HostPrograming', '82109914242'),
(10, 'MedArt Clinic in Florida', 'AyurHealing (Dr. Jyoti Lakhani)', 'HostPrograming', '8210991424'),
(11, 'MedArt Clinic Health System', 'Dr Supriya Dasgupta', 'pritesh', '7878872'),
(12, 'MedArt Clinic Health System', 'AyurHealing (Dr. Jyoti Lakhani)', 'HostPrograming', '53463346346'),
(13, 'MedArt Clinic Health System', 'Dr Tapan Khan Kr', 'susmita', '8017435362'),
(14, 'MedArt Clinic Health System', 'Dr Supriya Dasgupta', 'abc', '78904325'),
(16, 'MedArt Clinic in Florida', 'Dr Tapan Khan Kr', 'Dr. S Ghosh', '8210991424'),
(17, 'MedArt Clinic Children''s Center', 'A PHP Error was encountered Severity: Notice Message: Undefined variable: row Filename: views/Hello_', 'susmita', '991423242'),
(18, 'Gastroenterology', 'Dr Supriya Dasgupta', 'HostPrograming', '8210991424');

-- --------------------------------------------------------

--
-- Table structure for table `contect`
--

CREATE TABLE IF NOT EXISTS `contect` (
  `name` varchar(100) NOT NULL,
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `msg` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contect`
--

INSERT INTO `contect` (`name`, `id`, `email`, `subject`, `msg`) VALUES
('', 1, 'vivek65k@gmail.com', 'vhjhh', 'uy'),
('', 2, 'vivek65k@gmail.com', 'vivek', 'gyfguu'),
('vivekpandey', 3, 'vivek65k@gmail.com', 'ghj', 'tyftyuuhtft'),
('vivek kumar pandey', 4, 'ishikaca95@gmail.com', 'vivek', 'hey man, this is vivek kumar pandey');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `news` varchar(255) NOT NULL,
  `hours` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `spealist` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `date`, `news`, `hours`, `location`, `spealist`) VALUES
(4, 'Dr. Jennifer Jameson', '2018-11-21', 'Family Practice Physician', ' 10am-4pm', 'Kamarpara More Rd ,hooghly', 'cardiologist'),
(5, 'Dr. Ian Tong', '2018-11-29', 'Chief Medical Officer', ' 12pm-4pm', 'Hooghly Station Rd', ''),
(6, 'Dr Sopan Kumar Banerjee', '2018-11-23', 'Practice Physician', ' 10am-4pm', 'Kapasdanga P, Hooghly', 'Gastroenterology'),
(7, 'Dr Indranil Chowdhury', '2018-11-14', 'Medical Officer', ' 12pm-4pm', 'Chinsurah Station Road,hooghly', 'Pediatrician'),
(8, 'Dr anirban kar', '2018-11-23', 'MD', ' 10am-4pm', 'hooghly', 'child ');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `fistname` varchar(255) NOT NULL,
  `lastname` varchar(225) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confpassword` varchar(244) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fistname`, `lastname`, `email`, `password`, `confpassword`) VALUES
(1, 'vivek kumar pandey', 'April', 'vivek65k@gmail.com', 'vivek', 'rrr');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE IF NOT EXISTS `subscribe` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `subscribe` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`id`, `subscribe`) VALUES
(1, 'vivek65k@gmail.com'),
(4, 'hostprogramiing@gmail.com'),
(5, 'amit6565@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `unknown`
--

CREATE TABLE IF NOT EXISTS `unknown` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(225) NOT NULL,
  `number` bigint(255) NOT NULL,
  `massage` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `unknown`
--

INSERT INTO `unknown` (`id`, `name`, `email`, `number`, `massage`) VALUES
(1, 'vivek kumar pandey ', 'vivek65k@gmail.com', 8210991424, 'hii, this is vivek'),
(2, ' Arghya ', 'hostprograming65@gmail.com', 991423242, 'hii this is arghya ...here'),
(3, 'susmita', 'Hostprogramming65k@gmail.com', 991423242, 'hii susmita'),
(4, 'Amit Kumar pandey', 'pandeyishika501@gmail.com', 991423242, 'hii, This is Amit '),
(5, 'vivek kumar pandey 29 April', 'vivek65k@gmail.com', 991423242, 'hii,Vivek');

-- --------------------------------------------------------

--
-- Table structure for table `user_regstration`
--

CREATE TABLE IF NOT EXISTS `user_regstration` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_regstration`
--

INSERT INTO `user_regstration` (`id`, `username`, `email`, `password`) VALUES
(1, 'vivek kumar pandey', 'vivek65k@gmail.com', 'vivek'),
(2, 'susmita', 'susmitasen410@gmail.com', 'vivek');
